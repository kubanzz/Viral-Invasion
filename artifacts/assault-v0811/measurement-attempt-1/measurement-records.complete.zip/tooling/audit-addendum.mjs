import {createHash} from 'node:crypto';
import {open,readFile} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root=resolve(here,'../../..'),output=resolve(root,'artifacts/assault-v0811/measurement-attempt-1');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex'),sum=(rows,fn)=>rows.reduce((value,row)=>value+fn(row),0);
const groups={};
for(const name of ['baseline','candidate','candidate-new-policy']){
 const report=JSON.parse(await readFile(resolve(output,name,'report.json'),'utf8')),rows=[];
 for(const item of report.cases.filter(row=>!row.replay)){
  const bytes=await readFile(resolve(output,name,item.file));if(sha(bytes)!==item.rawSha256)throw Error('Raw bytes changed.');
  const raw=JSON.parse(bytes),a=raw.assaultObservation,c=raw.cycleObservation;
  const guardHits=a.acceptedCellHits.filter(hit=>hit.guard),assaultGuard=guardHits.filter(hit=>hit.assault);
  const guards=a.guards.map(guard=>({tick:guard.tick,at:guard.at,wave:guard.wave,newSquad:guard.data.newSquad,
   beaconId:guard.data.beaconId,plannedUntil:guard.data.plannedUntil,actualUntilAtEvent:guard.actualBeaconUntilAtEvent,
   actualUntilAfterPublicStep:guard.actualBeaconUntilAfterPublicStep,
   acceptedHits:guard.acceptedCellHits.length,travelAfterCommand:guard.travelAfterCommand,
   minimumCellDistanceToTissueAtCommand:guard.cellsAtCommand.length?Math.min(...guard.cellsAtCommand.map(cell=>Math.hypot(cell.x-guard.tissue.x,cell.y-guard.tissue.y))):null,
   preservedExistingCells:guard.data.newSquad?null:guard.cellsAtCommand.filter(cell=>guard.cellsBeforePublicStep.some(prior=>prior.id===cell.id&&prior.until===cell.until&&Math.hypot(prior.x-cell.x,prior.y-cell.y)<1e-7)).length}));
  const evidence={seed:item.seed,strategy:item.strategy,rawSha256:item.rawSha256,stop:raw.stop,clearedWaves:raw.clearedWaves,
   cycle:c.cycleEvidence,cycleWindows:c.cycleWindows.map(window=>({from:window.fromWave,to:window.toWave,kind:window.kind,
    contrast:window.releaseContrast,renewal:window.renewalObservation,ttkRatio:window.engagedTtkRatio,activePerKillRatio:window.activeSecondsPerKillRatio})),
   guard:{commands:guards,actualHits:guardHits.length,actualDamage:sum(guardHits,hit=>hit.actualHpLoss),
    actualAssaultHits:assaultGuard.length,actualAssaultDamage:sum(assaultGuard,hit=>hit.actualHpLoss),
    actualAssaultHitsWhenPlayerAway520:assaultGuard.filter(hit=>hit.playerTissueDistance>520).map(hit=>({tick:hit.tick,at:hit.at,wave:hit.wave,
     rootId:hit.rootId,targetId:hit.targetId,damage:hit.actualHpLoss,playerTissueDistance:hit.playerTissueDistance})),
    guardSeconds:sum(a.waves,wave=>wave.guardSeconds),guardPlayerAwaySeconds:sum(a.waves,wave=>wave.guardPlayerAwaySeconds),
    cellTravelDuringGuard:sum(a.waves,wave=>wave.cellTravelDuringGuard)},
   assault:{births:a.summary.assaultBorn,approached:a.summary.assaultApproachedTissue,cleared:a.summary.assaultCleared,
    telegraphs:a.actors.filter(actor=>actor.assault).flatMap(actor=>actor.telegraphs),
    displacements:a.actors.filter(actor=>actor.assault).flatMap(actor=>actor.displacements),
    actualTissueLossReceipts:a.actors.filter(actor=>actor.assault).flatMap(actor=>actor.tissueLoss)},
   actualLossReceipts:c.actualPlayerAndOrganLoss.filter(loss=>loss.type==='PLAYER_HURT'||loss.type==='ORGAN_INTEGRITY_CHANGED'&&loss.data.reason==='enemy-attack'),
   physicalCellDamageShare:sum(a.positiveDamage,hit=>hit.actualHpLoss)>0?sum(a.acceptedCellHits,hit=>hit.actualHpLoss)/sum(a.positiveDamage,hit=>hit.actualHpLoss):null};
  rows.push(evidence);
 }
 groups[name]=rows;
}
const candidate=groups.candidate,baseline=groups.baseline;
const result={scope:'Read-only derivation from the same22 frozen raw cases; no additional simulation. Guard plannedUntil is a controller snapshot, not actual expiry.',
 groups,comparativeCycle:{baseline:baseline.map(row=>({seed:row.seed,strategy:row.strategy,...row.cycle})),candidate:candidate.map(row=>({seed:row.seed,strategy:row.strategy,...row.cycle}))},
 limits:['Original9 candidate runs produced no assault telegraph despite162 actual births. Movement and real clearing alone do not prove renewed pressure.',
  'Guard damage is actual accepted physical damage, but three new-policy runs are not a same-policy causal comparison.',
  'Zero explicit rejection receipts is unobserved natural rejection-branch coverage. Old unmatched logs are not all rejected commands.',
  'New squads may receive the existing host lifetime growth after IMMUNE_GUARD_ASSIGNED. Existing-squad redirects preserve their real old lifetime and positions.',
  'No raw gameplay record, policy, frozen runtime or prior derived file was replaced. No new game run was added.']};
const path=resolve(output,'derived/guard-cycle-addendum.json'),handle=await open(path,'wx');try{await handle.writeFile(JSON.stringify(result,null,2)+'\n');}finally{await handle.close();}
console.log(JSON.stringify({path,cycles:{baseline:baseline.map(row=>({seed:row.seed,strategy:row.strategy,...row.cycle})),candidate:candidate.map(row=>({seed:row.seed,strategy:row.strategy,...row.cycle}))},newPolicy:groups['candidate-new-policy'].map(row=>({seed:row.seed,guardHits:row.guard.actualHits,guardDamage:row.guard.actualDamage,assaultGuardHits:row.guard.actualAssaultHits,
 assaultGuardDamage:row.guard.actualAssaultDamage,awayHits:row.guard.actualAssaultHitsWhenPlayerAway520.length,guardPlayerAwaySeconds:row.guard.guardPlayerAwaySeconds,cellTravel:row.guard.cellTravelDuringGuard}))},null,2));
