import {createHash} from 'node:crypto';
import {open,readFile} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root=resolve(here,'../../..'),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const plan=JSON.parse(await readFile(resolve(here,'plan.json'),'utf8'));
const oldOrigin=JSON.parse(await readFile(resolve(root,plan.baselineOriginReference),'utf8'));
const receiptPath='artifacts/assault-v0811/integration/frozen-source.json',receiptBytes=await readFile(resolve(root,receiptPath)),receipt=JSON.parse(receiptBytes);
const candidate=resolve(root,'.tools/assault-v0811-release');
if(resolve(receipt.target)!==candidate||receipt.version!=='0.8.11')throw Error('Unexpected coordinator freeze target/version.');
for(const[path,expected]of Object.entries({...receipt.overlays,...receipt.transformed}))if(sha(await readFile(resolve(candidate,path)))!==expected)throw Error(`Coordinator-frozen release drift:${path}`);
const paths=[...new Set([...Object.keys(oldOrigin.files),...Object.keys(receipt.overlays).filter(path=>/^src\/(game|actors|core)\/.+\.ts$/.test(path))])].sort();
const files={};for(const path of paths){
 const bytes=await readFile(resolve(candidate,path)),expected=receipt.overlays[path]??oldOrigin.files[path]?.sha256;
 if(sha(bytes)!==expected)throw Error(`Candidate helper/source not bound to freeze:${path}`);
 const old=oldOrigin.files[path];if(old&&sha(await readFile(resolve(root,plan.baselineRoot,path)))!==old.sha256)throw Error(`Baseline release differs from prior freeze:${path}`);
 files[path]={sha256:sha(bytes),bytes:bytes.length};
}
const writeNew=async(path,value)=>{const file=await open(path,'wx');try{await file.writeFile(JSON.stringify(value,null,2)+'\n');}finally{await file.close();}};
const origin={version:'0.8.11',sourceRelease:candidate,frozenSourceReceipt:receiptPath,frozenSourceReceiptSha256:sha(receiptBytes),
 scope:'All51 simulation and helper input paths bound to coordinator frozen release overlays, with unchanged helper hashes retained from the50-input v0810 origin. No live working-tree source copied.',files};
await writeNew(resolve(here,'candidate-origin.json'),origin);
const previous=JSON.parse(await readFile(resolve(root,'artifacts/assault-v0811/measurement-preparation.json'),'utf8'));
const bindings={};for(const name of ['plan.json','measure.mjs','assault-observer.mjs','guard-source-route.mjs','analyze.mjs','freeze-input.mjs']){const bytes=await readFile(resolve(here,name));bindings[name]={bytes:bytes.length,sha256:sha(bytes)};}
const amendment={at:new Date().toISOString(),preparedOnly:true,gameCompilation:false,simulationRuns:0,
 authorization:'Coordinator confirmed exact fixed19+3 once, overall release frozen; no strategy/seed/budget change.',
 sourceOriginSha256:sha(JSON.stringify(origin,null,2)+'\n'),sourceCount:paths.length,frozenSourceReceiptSha256:sha(receiptBytes),
 previousPreparationBindings:previous.bindings,bindings,
 observationBoundaryAmendment:'Before all compilation/runs, final gameplay API renamed guard event until to plannedUntil. Record plan separately; actual guard expiry is read only from live state beacon.until, including host existing growth bonus after public step. No event planned damage is promoted to actual damage.',
 changedPreparedFiles:['assault-observer.mjs: actual beacon state at event and completed public step, no equality with plannedUntil.','guard-source-route.mjs: record plannedUntil separately; route always checks actual state beacon.until.'],
 unchanged:['Registered plan','Exact original shared26-wave policy','New route decisions','Seeds,groups,budgets,failed-case stop rule']};
await writeNew(resolve(root,'artifacts/assault-v0811/measurement-prefreeze-amendment.json'),amendment);
console.log(JSON.stringify({sourceCount:paths.length,originSha256:amendment.sourceOriginSha256,receiptSha256:sha(receiptBytes),bindings},null,2));
