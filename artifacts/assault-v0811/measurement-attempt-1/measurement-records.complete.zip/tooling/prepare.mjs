import { createHash } from 'node:crypto';
import { mkdir, open, readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root=resolve(here,'../../..');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const plan=JSON.parse(await readFile(resolve(here,'plan.json'),'utf8'));
const files=['plan.json','measure.mjs','assault-observer.mjs','guard-source-route.mjs','prepare.mjs','analyze.mjs'];
const bindings={};for(const name of files){const bytes=await readFile(resolve(here,name));bindings[name]={bytes:bytes.length,sha256:sha(bytes)};}
const oldBytes=await readFile(resolve(root,plan.reuse.executedV088Driver)),old=oldBytes.toString('utf8').replaceAll('\r\n','\n');
const fragment=old.slice(old.indexOf('const priorities = {'),old.indexOf('\nexport function runObserved'));
const before="s.endless.clearedWaves >= 35) { stop = 'thirty-five-waves-cleared'",after="s.endless.clearedWaves >= 26) { stop = 'twenty-six-waves-cleared'";
if(fragment.indexOf(before)<0||fragment.indexOf(before)!==fragment.lastIndexOf(before))throw Error('Protected original policy extraction failed.');
const shared=fragment.replace(before,after);
if(shared.replace(after,before)!==fragment)throw Error('More than declared goal edit.');
const originBytes=await readFile(resolve(root,plan.baselineOriginReference));
if(sha(originBytes)!==plan.baselineOriginSha256)throw Error('Baseline origin changed.');
const record={at:new Date().toISOString(),preparedOnly:true,gameCompilation:false,simulationRuns:0,coordinatorAuthorization:'fixed19 original-policy +3 separately labeled new-policy cases; waiting overall freeze',
 bindings,oldExecutedDriverSha256:sha(oldBytes),oldPolicyFragmentSha256:sha(fragment),shared26WavePolicySha256:sha(shared),
 samePolicyChanges:['Exactly one35->26 cleared-wave goal substitution; original priorities,inputFor,firing,modal/public choices unchanged.'],
 baselineOriginSha256:sha(originBytes),baselineSourceFiles:Object.keys(JSON.parse(originBytes).files).length,
 baselineCases:9,candidateOriginalCases:10,candidateSeparateNewPolicyCases:3,totalFixedCases:22,retries:0,
 pending:['Coordinator overall candidate freeze','Candidate origin bound to release receipt','Compilation and all simulation cases explicitly deferred until freeze']};
await mkdir(resolve(root,'artifacts/assault-v0811'),{recursive:true});
const file=await open(resolve(root,'artifacts/assault-v0811/measurement-preparation.json'),'wx');
try{await file.writeFile(JSON.stringify(record,null,2)+'\n');}finally{await file.close();}
console.log(JSON.stringify(record,null,2));
