from pathlib import Path
import hashlib, json, zipfile

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = ROOT / 'artifacts/assault-v0811/measurement-attempt-1'
TOOLS = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()

payloads = {}
for path in sorted(OUTPUT.rglob('*')):
    if path.is_file() and not path.name.startswith('measurement-records.complete'):
        payloads[str(path.relative_to(OUTPUT)).replace('\\', '/')] = path
for path in sorted(TOOLS.iterdir()):
    if path.is_file():
        payloads['tooling/' + path.name] = path
references = {
    'binding-references/measurement-preparation.json': 'artifacts/assault-v0811/measurement-preparation.json',
    'binding-references/measurement-prefreeze-amendment.json': 'artifacts/assault-v0811/measurement-prefreeze-amendment.json',
    'binding-references/v0811-frozen-source.json': 'artifacts/assault-v0811/integration/frozen-source.json',
    'binding-references/v0810-frozen-source.json': 'artifacts/source-v0810/integration/frozen-source.json',
    'binding-references/v0810-measurement-origin.json': '.tools/source-v0810/measurement/frozen-candidate/origin.json',
    'binding-references/v088-candidate-report.json': 'artifacts/cycle-v088/measurement-attempt-1/candidate/report.json',
    'binding-references/v0810-source-matrix-report.json': 'artifacts/source-v0810/measurement-attempt-1/report.json',
}
for name, path in references.items():
    payloads[name] = ROOT / path

reports = {}
for cohort in ['baseline', 'candidate', 'candidate-new-policy']:
    report = json.loads((OUTPUT / cohort / 'report.json').read_text(encoding='utf-8'))
    if not report['mechanicalValidity'] or not report['sourcesUnchanged']:
        raise RuntimeError(f'Cannot certify invalid cohort: {cohort}')
    if report['executedCases'] != report['plannedCases']:
        raise RuntimeError(f'Unexecuted fixed cases: {cohort}')
    origin = json.loads((OUTPUT / cohort / 'frozen-origin.json').read_text(encoding='utf-8'))
    source_root = Path(report['sourceDirectory'])
    for path, entry in origin['files'].items():
        if sha((source_root / path).read_bytes()) != entry['sha256']:
            raise RuntimeError(f'Origin drift: {cohort}/{path}')
    for row in report['cases']:
        if sha((OUTPUT / cohort / row['file']).read_bytes()) != row['rawSha256']:
            raise RuntimeError(f'Raw drift: {cohort}/{row["file"]}')
    reports[cohort] = {'cases': len(report['cases']), 'sourceCount': report['sourceCount'],
        'reportSha256': sha((OUTPUT / cohort / 'report.json').read_bytes()), 'replay': report['replay']}

entries = [{'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
           for name, path in sorted(payloads.items())]
manifest = {'scope': 'Complete fixed22 public-input records, parsed frozen sources, policies, observers, derivations and binding references. No replaced seed or retry.',
    'payloadCount': len(entries), 'fixedCases': 22, 'reports': reports, 'entries': entries}
manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
archive = OUTPUT / 'measurement-records.complete.zip'
with archive.open('xb') as handle:
    with zipfile.ZipFile(handle, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, path in sorted(payloads.items()):
            bundle.writestr(name, path.read_bytes())
        bundle.writestr('measurement-records.complete.manifest.json', manifest_bytes)
with zipfile.ZipFile(archive) as bundle:
    if bundle.testzip() is not None or len(bundle.namelist()) != len(entries) + 1:
        raise RuntimeError('ZIP CRC/entry count failed')
    for row in entries:
        data = bundle.read(row['path'])
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise RuntimeError(f'ZIP byte/hash verification failed: {row["path"]}')
    if bundle.read('measurement-records.complete.manifest.json') != manifest_bytes:
        raise RuntimeError('Embedded manifest changed')
with (OUTPUT / 'measurement-records.complete.manifest.json').open('xb') as handle:
    handle.write(manifest_bytes)
index = {'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()),
    'payloadCount': len(entries), 'zipEntriesIncludingManifest': len(entries) + 1,
    'manifestSha256': sha(manifest_bytes), 'fixedCases': 22,
    'verification': 'Every22 raw case, every50/51 origin input, all payload bytes/hash, embedded manifest and ZIP CRC verified. Original evidence remains on disk.'}
with (OUTPUT / 'measurement-records.complete.index.json').open('x', encoding='utf-8') as handle:
    json.dump(index, handle, ensure_ascii=False, indent=2)
    handle.write('\n')
print(json.dumps(index, ensure_ascii=False, indent=2))
