import { createHash } from 'node:crypto';
import { mkdir, open, readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root=resolve(here,'../../..'),plan=JSON.parse(await readFile(resolve(here,'plan.json'),'utf8'));
const output=resolve(root,plan.output),derived=resolve(output,'derived');await mkdir(derived);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const sum=(rows,fn)=>rows.reduce((total,row)=>total+(fn(row)??0),0);
const writeNew=async(name,value)=>{const handle=await open(resolve(derived,name),'wx');try{await handle.writeFile(typeof value==='string'?value:JSON.stringify(value,null,2)+'\n');}finally{await handle.close();}};
const cohorts={};
for(const name of ['baseline','candidate','candidate-new-policy']){
 const reportBytes=await readFile(resolve(output,name,'report.json')),report=JSON.parse(reportBytes);
 const cases=[];for(const row of report.cases){const bytes=await readFile(resolve(output,name,row.file));if(sha(bytes)!==row.rawSha256)throw Error(`Raw identity changed:${name}/${row.file}`);
  const raw=JSON.parse(bytes),a=raw.assaultObservation,c=raw.cycleObservation,source=raw.sourceObservation;
  const cells=a.acceptedCellHits,enemyLoss=sum(c.actualPlayerAndOrganLoss.filter(loss=>loss.type==='ORGAN_INTEGRITY_CHANGED'&&loss.data.reason==='enemy-attack'),loss=>loss.actualLoss);
  cases.push({...row,elapsed:raw.elapsed,playerLoss:raw.cumulativePlayerDamage,organTotalLoss:raw.cumulativeTissueLoss,enemyOrganLoss:enemyLoss,
   inputCounts:raw.inputCounts,actualToolDamage:raw.toolDamage,finalRanks:raw.finalRanks,finalStats:raw.finalStats,
   damageAuthority:{all:sum(a.positiveDamage,hit=>hit.actualHpLoss),cell:sum(cells,hit=>hit.actualHpLoss),cellHits:cells.length,
    cellAssault:sum(cells.filter(hit=>hit.assault),hit=>hit.actualHpLoss),cellSource:sum(cells.filter(hit=>hit.source),hit=>hit.actualHpLoss)},
   assault:a.summary,cycleEvidence:c.cycleEvidence,source:{kills:source.sources.filter(item=>item.actualKill).length,exhaustions:source.sources.filter(item=>item.naturalExhaustion).length,
    canceled:sum(source.sources,item=>item.canceled),quotaBorn:sum(source.sources,item=>item.quotaBorn),actualDamage:sum(source.sources,item=>item.actualSourceDamage),
    warnings:source.sources.map(item=>({wave:item.wave,warning:item.actualAnnouncementToBirth,firstHitDelay:item.timeBirthToFirstHit,kill:item.actualKill,exhausted:item.naturalExhaustion}))},
   waves:c.waves.map(w=>({wave:w.wave,combatSeconds:w.combatSeconds,livingCombatSeconds:w.liveSeconds,damage:w.damage,cellDamage:w.cellDamage,shots:w.shots,
    commits:w.commits,tissueDangerSeconds:w.tissueDangerSeconds,playerDangerSeconds:w.playerDangerSeconds,ordinary:w.ordinary,maxHpBacklog:w.maxHpBacklog,
    emptyScheduledSeconds:w.emptyScheduledSeconds,emptyFissionSeconds:w.emptyFissionSeconds})),newPolicyObservation:raw.newPolicyObservation});
 }
 cohorts[name]={reportSha256:sha(reportBytes),mechanicalValidity:report.mechanicalValidity,plannedCases:report.plannedCases,executedCases:report.executedCases,unexecutedCases:report.unexecutedCases,
  sourceCount:report.sourceCount,bundleSha256:report.bundleSha256,sourcesUnchanged:report.sourcesUnchanged,replay:report.replay,cases};
}
const pairs=[];for(const seed of plan.seeds)for(const strategy of plan.strategies){
 const b=cohorts.baseline.cases.find(row=>row.seed===seed&&row.strategy===strategy&&!row.replay),n=cohorts.candidate.cases.find(row=>row.seed===seed&&row.strategy===strategy&&!row.replay);
 if(!b||!n){pairs.push({seed,strategy,missing:true});continue;}
 const delta={};for(const field of ['elapsed','score','playerLoss','organTotalLoss','enemyOrganLoss'])delta[field]=n[field]-b[field];
 pairs.push({seed,strategy,baseline:{stop:b.stop,clearedWaves:b.clearedWaves,elapsed:b.elapsed,score:b.score,damage:b.damageAuthority,assault:b.assault,source:b.source,cycleEvidence:b.cycleEvidence,inputCounts:b.inputCounts,actualToolDamage:b.actualToolDamage},
  candidate:{stop:n.stop,clearedWaves:n.clearedWaves,elapsed:n.elapsed,score:n.score,damage:n.damageAuthority,assault:n.assault,source:n.source,cycleEvidence:n.cycleEvidence,inputCounts:n.inputCounts,actualToolDamage:n.actualToolDamage},delta});
}
const totals={};for(const[name,cohort]of Object.entries(cohorts)){const cases=cohort.cases.filter(row=>!row.replay);
 totals[name]={cases:cases.length,clear26:cases.filter(row=>row.clearedWaves>=26).length,naturalFailures:cases.filter(row=>row.stop==='real-failure').length,
  elapsed:sum(cases,row=>row.elapsed),playerLoss:sum(cases,row=>row.playerLoss),organTotalLoss:sum(cases,row=>row.organTotalLoss),enemyOrganLoss:sum(cases,row=>row.enemyOrganLoss),
  score:sum(cases,row=>row.score),allActualDamage:sum(cases,row=>row.damageAuthority.all),cellActualDamage:sum(cases,row=>row.damageAuthority.cell),cellHits:sum(cases,row=>row.damageAuthority.cellHits),
  assaultBorn:sum(cases,row=>row.assault.assaultBorn),assaultApproached:sum(cases,row=>row.assault.assaultApproachedTissue),assaultTelegraphs:sum(cases,row=>row.assault.assaultTelegraphs),
  assaultTissueTelegraphs:sum(cases,row=>row.assault.assaultTissueTelegraphs),assaultOrganLoss:sum(cases,row=>row.assault.assaultActualTissueLoss),
  assaultCleared:sum(cases,row=>row.assault.assaultCleared),assaultPositiveAreaDisplacements:sum(cases,row=>row.assault.assaultPositiveAreaDisplacements),
  cellAssaultDamage:sum(cases,row=>row.damageAuthority.cellAssault),cellSourceDamage:sum(cases,row=>row.damageAuthority.cellSource),
  unmatchedBiteLogs:sum(cases,row=>row.assault.unmatchedBiteLogs),mismatchedPositiveBiteLogDamage:sum(cases,row=>row.assault.mismatchedPositiveBiteLogDamage),
  explicitRejectedBites:sum(cases,row=>row.assault.explicitRejectedBites),rejectedClockRefunds:sum(cases,row=>row.assault.rejectedClockRefunds),
  guards:sum(cases,row=>row.assault.guards),guardHits:sum(cases,row=>row.assault.guardHits),guardDamage:sum(cases,row=>row.assault.guardDamage),
  guardAssaultDamageWhilePlayerAway520:sum(cases,row=>row.assault.guardAssaultDamageWhilePlayerAway520),
  sourceKills:sum(cases,row=>row.source.kills),sourceExhaustions:sum(cases,row=>row.source.exhaustions),sourceCanceled:sum(cases,row=>row.source.canceled),sourceQuotaBorn:sum(cases,row=>row.source.quotaBorn)};
}
const result={scope:plan.scope,authority:'Every damage total uses positive accepted TARGET_HIT. Logs, Q attempts, threat footprints, canceled quota and source unspent HP are never damage.',
 comparisonDesign:'Nine same-policy pairs plus one predetermined candidate replay. Three candidate guard-then-source runs are a separate new-policy cohort.',
 fixedPlan:{seeds:plan.seeds,strategies:plan.strategies,goalWaves:26,simulationSeconds:900,simulationSecondsPerWave:120,retries:0},totals,pairs,cohorts,
 limits:['Combined candidate includes assault,guard andbite corrections; not single-variable attribution.','area retains original1/2 andfallback upgrades; it is not a pure2 build.','No required injury, Q, bite contribution, win or balancing target.','Old explicit rejection count is unavailable; unmatched logs and mismatched log damage are observable separately.','Frozen-step danger and script clear speed are mechanical proxies only. Human blind playtest remains0/5.']};
await writeNew('comparison.json',result);
const f=value=>typeof value==='number'?value.toFixed(3):String(value);
let md='# v0.8.11 固定公开输入比较\n\n原19局比较与新增3局驻防路线分别汇总。所有伤害以实际接受的正HP损失为准；无补跑。\n\n';
md+='|种子/原策略|v0810秒|v0811秒|差值秒|旧/新cell伤害|新袭击出生/组织起手/正损失|旧/新分数|\n|---|---:|---:|---:|---:|---:|---:|\n';
for(const p of pairs)md+=p.missing?`|${p.seed}/${p.strategy}|缺失||||||\n`:`|${p.seed}/${p.strategy}|${f(p.baseline.elapsed)}|${f(p.candidate.elapsed)}|${f(p.delta.elapsed)}|${f(p.baseline.damage.cell)}/${f(p.candidate.damage.cell)}|${p.candidate.assault.assaultBorn}/${p.candidate.assault.assaultTissueTelegraphs}/${f(p.candidate.assault.assaultActualTissueLoss)}|${p.baseline.score}/${p.candidate.score}|\n`;
md+='\n新增guard-then-source政策（不混入原九组版本差异）：\n\n|种子|清波|秒|受理guard|guard实际伤害|玩家离组织>520时guard对袭击者伤害|实际source击杀/枯竭|\n|---|---:|---:|---:|---:|---:|---:|\n';
for(const r of cohorts['candidate-new-policy'].cases)md+=`|${r.seed}|${r.clearedWaves}|${f(r.elapsed)}|${r.assault.guards}|${f(r.assault.guardDamage)}|${f(r.assault.guardAssaultDamageWhilePlayerAway520)}|${r.source.kills}/${r.source.exhaustions}|\n`;
md+='\n计划咬击日志不代表成功；旧版没有显式拒绝receipt。清场节奏、威胁与贡献是技术观测，真人趣味/反制理解/复玩尚未验收（0/5）。完整停止原因、负面/零贡献与未执行条目见comparison.json。\n';
await writeNew('comparison.md',md);console.log(JSON.stringify({derived,totals},null,2));
