import hashlib,json,pathlib,stat,zipfile
from datetime import datetime,timezone
tool_dir=pathlib.Path(__file__).resolve().parent
root=tool_dir.parents[2]; output=root/'artifacts/source-v089/measurement-attempt-1'
archive=output/'measurement-records.complete.zip'
manifest_path=output/'measurement-records.complete.manifest.json'
index_path=output/'measurement-records.complete.index.json'
if any(p.exists() for p in [archive,manifest_path,index_path]):raise RuntimeError('Preserve existing complete archive')
sha=lambda data:hashlib.sha256(data).hexdigest()
origin_path=tool_dir/'frozen-candidate/origin.json';origin=json.loads(origin_path.read_text(encoding='utf-8'))
assert len(origin['files'])==50
paths={p.relative_to(output).as_posix():p for p in sorted(output.rglob('*')) if p.is_file() and not p.relative_to(output).as_posix().startswith('measurement-records.')}
for name in ['plan.json','measure.mjs','source-observer.mjs','analyze.mjs','archive.py','archive-complete.py']:
 paths['tools/'+name]=tool_dir/name
paths['frozen-candidate/origin.json']=origin_path
for rel,entry in origin['files'].items():
 p=tool_dir/'frozen-candidate'/rel
 assert not p.is_symlink() and sha(p.read_bytes())==entry['sha256'] and p.stat().st_size==entry['bytes']
 paths['frozen-candidate/'+rel]=p
for p in paths.values():
 if p.is_symlink():raise RuntimeError(f'No links: {p}')
entries=[{'path':name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'kind':'raw-case' if name.startswith('seed-') and name.endswith('.json') else 'derived' if name.startswith('derived/') else 'complete-frozen-candidate' if name.startswith('frozen-candidate/') else 'parsed-frozen-source' if name.startswith('frozen-source/') else 'tool-bundle-or-binding'} for name,path in sorted(paths.items())]
assert sum(e['kind']=='raw-case' for e in entries)==13
assert sum(e['kind']=='complete-frozen-candidate' and e['path']!='frozen-candidate/origin.json' for e in entries)==50
manifest={'schemaVersion':1,'createdAtUtc':datetime.now(timezone.utc).isoformat(),'rawCases':13,'independentCases':12,'predeterminedReplayCases':1,
 'completeFrozenCandidateFiles':50,'completeFrozenOriginSha256':sha(origin_path.read_bytes()),
 'scope':'Original fixed13 public-input runs, all50 frozen candidate inputs, actual parsed-source copies, self-contained simulation bundle, executed tools/strategy/observers and complete derived analyses. Original records and the prior smaller-scope archive remain on disk; no reruns.',
 'priorArchive':'measurement-records.zip retained. That earlier payload held parsed source, not all50 frozen source files. This complete archive adds actual bytes of every origin input; no simulation counts are added.',
 'limits':['Score/bestCombo objectives were explicitly requested after running and remain marked posthoc, separate from the original Pareto objectives.',
 'SOURCE_EXHAUSTED is finite target removal, not accepted damage, TARGET_CLEARED or XP. Remaining source HP is never summed as player damage.',
 'An original last-budget snapshot can carry a next-wave stamp. Derived records expose it; actual current-state budget assertions were retained and passed.'],
 'manifestRule':'Hashes cover every payload entry; archive-manifest.json embeds these exact manifest bytes, separately hashed in the external index.', 'files':entries}
manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
with manifest_path.open('xb') as f:f.write(manifest_bytes)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for entry in entries:z.write(paths[entry['path']],entry['path'])
 z.writestr('archive-manifest.json',manifest_bytes)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 infos=z.infolist();names=[i.filename for i in infos]
 assert len(names)==len(set(names))==len(entries)+1 and set(names)==set(paths)|{'archive-manifest.json'}
 assert all(not stat.S_ISLNK(i.external_attr>>16) for i in infos)
 assert z.read('archive-manifest.json')==manifest_bytes
 for entry in entries:
  data=z.read(entry['path']);assert len(data)==entry['bytes'] and sha(data)==entry['sha256']
  assert sha(paths[entry['path']].read_bytes())==entry['sha256']
 for rel,entry in origin['files'].items():assert sha(z.read('frozen-candidate/'+rel))==entry['sha256']
index={'archive':archive.relative_to(root).as_posix(),'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),
 'manifest':manifest_path.relative_to(root).as_posix(),'manifestSha256':sha(manifest_bytes),'payloadFiles':len(entries),'zipEntries':len(entries)+1,
 'rawCases':13,'completeFrozenCandidateFiles':50,'independentCases':12,'predeterminedReplayCases':1,
 'crcPassed':True,'allUncompressedPayloadHashesMatch':True,'all50FrozenInputBytesMatchOrigin':True,'originalFilesUnchangedAndRetained':True,
 'scope':manifest['scope'],'priorArchive':manifest['priorArchive'],'limits':manifest['limits']}
with index_path.open('x',encoding='utf-8') as f:json.dump(index,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(index,ensure_ascii=False))
