import hashlib,json,pathlib,stat,zipfile
from datetime import datetime,timezone
root=pathlib.Path(__file__).resolve().parents[3]
output=root/'artifacts/source-v089/measurement-attempt-1'
archive=output/'measurement-records.zip'; manifest_path=output/'measurement-records.manifest.json'; index_path=output/'measurement-records.index.json'
if any(p.exists() for p in [archive,manifest_path,index_path]):raise RuntimeError('Preserve the original measurement archive')
sha=lambda data:hashlib.sha256(data).hexdigest()
paths={p.relative_to(output).as_posix():p for p in sorted(output.rglob('*')) if p.is_file()}
for name in ['plan.json','measure.mjs','source-observer.mjs','analyze.mjs','archive.py']:
 paths['tools/'+name]=pathlib.Path(__file__).with_name(name)
for p in paths.values():
 if p.is_symlink():raise RuntimeError(f'No links: {p}')
entries=[{'path':name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'kind':'raw-case' if name.startswith('seed-') and name.endswith('.json') else 'derived' if name.startswith('derived/') else 'frozen-source' if name.startswith('frozen-source/') else 'tool-bundle-or-binding'} for name,path in sorted(paths.items())]
assert sum(e['kind']=='raw-case' for e in entries)==13
manifest={'schemaVersion':1,'createdAtUtc':datetime.now(timezone.utc).isoformat(),'rawCases':13,'independentCases':12,'predeterminedReplayCases':1,
 'scope':'Immutable fixed13 public-input source-route simulation. No raw deletion, browser, GPU measurement or human balance/fun conclusion.',
 'limits':['Pre-registered time/player-loss/organ-total-loss Pareto and post-run requested existing score/bestCombo objectives are separate in derived/comparison.json.',
 'SOURCE_EXHAUSTED is finite target removal; its unspent HP is neither actual damage nor TARGET_CLEARED/XP. Actual positive HP receipts and explicit quota cancellations are preserved.',
 'An original last-budget sample at a wave transition can carry the next-wave stamp. Derived records expose this limitation; actual current-state budget assertions were retained and passed.'],
 'manifestRule':'Hashes cover every payload entry. archive-manifest.json embeds these exact bytes and its separate hash is in the external index.', 'files':entries}
manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
with manifest_path.open('xb') as f:f.write(manifest_bytes)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for entry in entries:z.write(paths[entry['path']],entry['path'])
 z.writestr('archive-manifest.json',manifest_bytes)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 infos=z.infolist(); names=[i.filename for i in infos]
 assert len(names)==len(set(names))==len(entries)+1 and set(names)==set(paths)|{'archive-manifest.json'}
 assert all(not stat.S_ISLNK(i.external_attr>>16) for i in infos)
 assert z.read('archive-manifest.json')==manifest_bytes
 for entry in entries:
  content=z.read(entry['path']);assert len(content)==entry['bytes'] and sha(content)==entry['sha256']
  assert sha(paths[entry['path']].read_bytes())==entry['sha256']
index={'archive':archive.relative_to(root).as_posix(),'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),
 'manifest':manifest_path.relative_to(root).as_posix(),'manifestSha256':sha(manifest_bytes),'payloadFiles':len(entries),'zipEntries':len(entries)+1,
 'rawCases':13,'independentCases':12,'predeterminedReplayCases':1,'crcPassed':True,'allUncompressedPayloadHashesMatch':True,'originalFilesUnchangedAndRetained':True,
 'scope':manifest['scope'],'limits':manifest['limits']}
with index_path.open('x',encoding='utf-8') as f:json.dump(index,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(index,ensure_ascii=False))
