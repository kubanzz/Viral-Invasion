import pathlib,json,hashlib,zipfile,stat
from datetime import datetime,timezone
tool=pathlib.Path(__file__).resolve().parent;root=tool.parents[2]
output=root/'artifacts/source-v089/late-adaptation-attempt-1';prior=root/'artifacts/source-v089/measurement-attempt-1'
archive=output/'late-adaptation-records.zip';manifest_path=output/'late-adaptation-records.manifest.json';index_path=output/'late-adaptation-records.index.json'
if any(p.exists() for p in [archive,manifest_path,index_path,output/'scope-addendum.json']):raise RuntimeError('Preserve prior late archive')
sha=lambda data:hashlib.sha256(data).hexdigest()
addendum={'reportedAtUtc':datetime.now(timezone.utc).isoformat(),'newRuns':2,'caseScope':'seed71 shooting/immune rush from1 to26, original frozen v089 runtime. No additional runs after these two.',
 'interactionResult':'Two declared adaptive/source boundary cases passed their scoped state/event/accounting assertions.',
 'knownSeparateRegression':'Coordinator subsequently confirmed the same v089 living source blocks the existing fast-clear pursuit acceleration. It is being fixed separately in v0.8.10. These state-transition qualifications do not close that cadence regression or prove user gameplay goals.',
 'priorRouteInterpretation':'Old rush/near time advantages can mix actual canceled-quota utility with this unintended scheduling wait. Do not attribute all of that advantage to a balanced route choice.',
 'unchangedEvidence':'Original13 and both late raw records/reports remain unchanged. No failed result is relabeled or rerun.'}
(output/'scope-addendum.json').write_text(json.dumps(addendum,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
paths={p.relative_to(output).as_posix():p for p in sorted(output.rglob('*')) if p.is_file()}
for name in ['late-adaptation.mjs','archive-late.py']:paths['tools/'+name]=tool/name
origin_path=tool/'frozen-candidate/origin.json';origin=json.loads(origin_path.read_text(encoding='utf-8'))
paths['frozen-candidate/origin.json']=origin_path
for rel,entry in origin['files'].items():
 p=tool/'frozen-candidate'/rel;assert sha(p.read_bytes())==entry['sha256'];paths['frozen-candidate/'+rel]=p
for name in ['report.json','strategy-compatibility.json','seed-71-shooting-rush.json','seed-71-immune-rush.json']:
 paths['reference-original13/'+name]=prior/name
entries=[]
for name,p in sorted(paths.items()):
 assert not p.is_symlink();data=p.read_bytes();entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
assert sum(e['path'].startswith('seed-') and e['path'].endswith('-rush.json') for e in entries)==2
assert len(origin['files'])==50
manifest={'schemaVersion':1,'scope':addendum,'newRawCases':2,'referenceOriginal13RawCases':2,'fullFrozenCandidateInputs':50,
 'manifestRule':'All payloads are hashed. archive-manifest.json embeds these manifest bytes and is separately hashed by the external index.', 'files':entries}
data=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
with manifest_path.open('xb') as f:f.write(data)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for entry in entries:z.write(paths[entry['path']],entry['path'])
 z.writestr('archive-manifest.json',data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None;names=z.namelist();assert len(names)==len(set(names))==len(entries)+1
 assert set(names)==set(paths)|{'archive-manifest.json'}
 assert all(not stat.S_ISLNK(i.external_attr>>16) for i in z.infolist())
 assert z.read('archive-manifest.json')==data
 for entry in entries:
  content=z.read(entry['path']);assert len(content)==entry['bytes'] and sha(content)==entry['sha256']
  assert sha(paths[entry['path']].read_bytes())==entry['sha256']
index={'archive':archive.relative_to(root).as_posix(),'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),
 'manifest':manifest_path.relative_to(root).as_posix(),'manifestSha256':sha(data),'payloadFiles':len(entries),'zipEntries':len(entries)+1,
 'newRuns':2,'referenceOriginal13Runs':2,'frozenCandidateFiles':50,'crcPassed':True,'allUncompressedHashesMatch':True,'originalEvidenceRetainedUnchanged':True,'scopeAddendum':addendum}
with index_path.open('x',encoding='utf-8') as f:json.dump(index,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(index,ensure_ascii=False))
