import hashlib
import json
import pathlib
import stat
import zipfile
from datetime import datetime, timezone

root = pathlib.Path(__file__).resolve().parents[2]
output = root / 'artifacts/cycle-v088/measurement-attempt-1'
archive = output / 'measurement-records.zip'
manifest_path = output / 'measurement-records.manifest.json'
index_path = output / 'measurement-records.index.json'
share_path = output / 'derived/contribution-share-addendum.json'
if any(p.exists() for p in [archive, manifest_path, index_path, share_path]):
    raise RuntimeError('Preserve existing measurement packaging artifacts')
sha = lambda value: hashlib.sha256(value).hexdigest()
share_rows = []
for version in ['baseline', 'candidate']:
    report = json.loads((output / version / 'report.json').read_text(encoding='utf-8'))
    for row in report['cases']:
        if row['replay'] or row['strategy'] == 'noncounter':
            continue
        run = json.loads((output / 'derived' / f"{version}-seed-{row['seed']}-{row['strategy']}.json").read_text(encoding='utf-8'))
        total = run['actualDamage']; immune = run['actualImmune']['damage']
        share_rows.append({'version': version, 'seed': row['seed'], 'strategy': row['strategy'],
                           'totalActualAcceptedDamage': total, 'actualImmuneDamage': immune,
                           'immuneActualDamageShare': immune / total if total else None})
groups = []
for version in ['baseline', 'candidate']:
    rows = [r for r in share_rows if r['version'] == version]
    total = sum(r['totalActualAcceptedDamage'] for r in rows); immune = sum(r['actualImmuneDamage'] for r in rows)
    groups.append({'version': version, 'independentCases': len(rows), 'totalActualAcceptedDamage': total,
                   'actualImmuneDamage': immune, 'immuneActualDamageShare': immune / total})
share = {'method': 'Sum existing immutable derived actual-damage receipts, 9 independent normal cases per version; negatives and replay excluded.',
         'groups': groups, 'cases': share_rows,
         'limit': 'Enemy health availability, clear time, growth and pursuit all changed. Damage share controls the different available HP totals only partially and is not a single-variable immune buff experiment.'}
share_path.write_text(json.dumps(share, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
files = {}
for folder in ['baseline', 'candidate', 'derived']:
    for p in sorted((output / folder).rglob('*')):
        if not p.is_file():
            continue
        if p.is_symlink():
            raise RuntimeError(f'No measurement links: {p}')
        files[p.relative_to(output).as_posix()] = p
tool_dir = root / '.tools/cadence-v088'
for name in ['plan.json', 'prepare-baseline.py', 'measure.mjs', 'observer.mjs', 'analyze.mjs', 'archive-measurements.py']:
    files[f'tools/{name}'] = tool_dir / name
for label in ['baseline-v087', 'candidate-v088']:
    files[f'tools/{label}-origin.json'] = tool_dir / label / 'origin.json'
entries = []
for name, path in sorted(files.items()):
    data = path.read_bytes()
    kind = 'raw-case' if name.split('/')[0] in ['baseline', 'candidate'] and name.split('/')[-1].startswith('seed-') else 'derived' if name.startswith('derived/') else 'frozen-source' if '/frozen-source/' in name else 'tool-binding-or-bundle'
    entries.append({'path': name, 'kind': kind, 'bytes': len(data), 'sha256': sha(data)})
raw_cases = [r for r in entries if r['kind'] == 'raw-case']
assert len(raw_cases) == 21
manifest = {'schemaVersion': 1, 'createdAtUtc': datetime.now(timezone.utc).isoformat(),
            'scope': 'Immutable fixed21 Node public-input runs, frozen simulation bundles/sources, executed tools and separate derived analyses. Original raw files remain on disk.',
            'rawCases': 21, 'independentNormalCases': 18, 'independentNegativeCases': 2, 'predeterminedReplays': 1,
            'baselineInstrumentationCorrection': 'Original baseline observer immune=0 fields are retained. Uniform positive TARGET_HIT cell/:bite root derivation is a separate supplement; baseline contact/LOS was not sampled. Candidate observer identity fallback and runtime-only proof limits are recorded in candidate/observer-amendment.json.',
            'selfManifestRule': 'This list hashes every payload entry. archive-manifest.json embeds these exact manifest bytes and is separately hashed by the external index; no self-referential hash.',
            'files': entries}
manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
with manifest_path.open('xb') as f:
    f.write(manifest_bytes)
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for entry in entries:
        z.write(files[entry['path']], entry['path'])
    z.writestr('archive-manifest.json', manifest_bytes)
with zipfile.ZipFile(archive, 'r') as z:
    assert z.testzip() is None
    actual = z.infolist(); names = [i.filename for i in actual]
    assert len(names) == len(set(names)) == len(entries) + 1
    assert set(names) == set(files) | {'archive-manifest.json'}
    assert all(not stat.S_ISLNK(i.external_attr >> 16) for i in actual)
    assert z.read('archive-manifest.json') == manifest_bytes
    for entry in entries:
        content = z.read(entry['path'])
        assert sha(content) == entry['sha256'] and len(content) == entry['bytes']
        assert sha(files[entry['path']].read_bytes()) == entry['sha256']
index = {'schemaVersion': 1, 'archive': archive.relative_to(root).as_posix(), 'archiveBytes': archive.stat().st_size,
         'archiveSha256': sha(archive.read_bytes()), 'manifest': manifest_path.relative_to(root).as_posix(),
         'manifestSha256': sha(manifest_bytes), 'zipEntries': len(entries) + 1, 'payloadFiles': len(entries),
         'rawCases': 21, 'crcPassed': True, 'allUncompressedPayloadHashesMatch': True, 'originalFilesUnchangedAndRetained': True,
         'scope': manifest['scope'], 'baselineInstrumentationCorrection': manifest['baselineInstrumentationCorrection'],
         'contributionShareAddendum': share_path.relative_to(root).as_posix()}
with index_path.open('x', encoding='utf-8') as f:
    json.dump(index, f, ensure_ascii=False, indent=2); f.write('\n')
print(json.dumps({'index': str(index_path), **index, 'damageShareGroups': groups}, ensure_ascii=False))
