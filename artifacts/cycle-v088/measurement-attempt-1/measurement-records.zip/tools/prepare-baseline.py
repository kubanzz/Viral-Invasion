import hashlib
import json
import pathlib
import zipfile

root = pathlib.Path(__file__).resolve().parents[2]
plan_path = pathlib.Path(__file__).with_name('plan.json')
plan = json.loads(plan_path.read_text(encoding='utf-8'))
target = pathlib.Path(__file__).with_name('baseline-v087')
if target.exists():
    raise RuntimeError('Preserve the prior frozen baseline directory')
sha = lambda value: hashlib.sha256(value).hexdigest()
archive = root / plan['baselineArchive']
assert sha(archive.read_bytes()) == plan['baselineArchiveSha256']
manifest_bytes = (root / plan['baselineManifest']).read_bytes()
manifest = json.loads(manifest_bytes)
selected = {}
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(set(names)) == 452
    assert set(names) == set(manifest)
    target.mkdir()
    for name in sorted(names):
        if not (name.startswith('src/') or name.startswith('tests/helpers/') or name in ['package.json', 'package-lock.json']):
            continue
        p = pathlib.PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in name
        content = z.read(name)
        assert sha(content) == manifest[name]['sha256'] and len(content) == manifest[name]['bytes']
        destination = target / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
        selected[name] = manifest[name]
report = {'archive': plan['baselineArchive'], 'archiveSha256': plan['baselineArchiveSha256'],
          'frozenManifest': plan['baselineManifest'], 'frozenManifestSha256': sha(manifest_bytes),
          'method': 'Only frozen source ZIP src/, tests/helpers/ and package manifests extracted. No root production source, node_modules, dist, generated artwork or simulation state copied.',
          'files': selected}
(target / 'origin.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'prepared': True, 'simulationRuns': 0, 'target': str(target), 'files': len(selected)}))
