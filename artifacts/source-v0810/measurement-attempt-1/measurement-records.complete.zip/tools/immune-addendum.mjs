import{createHash}from'node:crypto';import{open,readFile}from'node:fs/promises';import{dirname,resolve}from'node:path';import{fileURLToPath}from'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root=resolve(here,'../../..'),output=resolve(root,'artifacts/source-v0810/measurement-attempt-1');
const report=JSON.parse(await readFile(resolve(output,'report.json'),'utf8')),sha=data=>createHash('sha256').update(data).digest('hex'),sum=values=>values.reduce((a,b)=>a+b,0);
const cases=[];
for(const task of report.cases){
 const bytes=await readFile(resolve(output,task.file));if(sha(bytes)!==task.rawSha256)throw Error('Raw changed');
 const raw=JSON.parse(bytes),obs=raw.cycleObservation,seen=new Set(),duplicates=[],hits=[];
 for(const hit of obs.acceptedDamageReceipts){
  const match=hit.protocolId==='IMMUNE_BEACON'&&hit.damage>0&&typeof hit.rootId==='string'?hit.rootId.match(/^(.+:cell:\d+):bite:(\d+)$/):null;
  if(!match||Number(match[2])!==hit.tick)continue;
  const key=`${hit.tick}:${hit.rootId}:${hit.id}`;if(seen.has(key)){duplicates.push(key);continue;}seen.add(key);hits.push(hit);
 }
 const damage=sum(hits.map(h=>h.damage)),old=raw.damage.immuneSubset;
 if(Math.abs(damage-old)>1e-6*Math.max(1,damage)||hits.length!==raw.damageHits.immuneSubset)throw Error('Actual-root derived cell damage differs from original positive-damage counter');
 const sources=raw.sourceObservation.sources.map(s=>({id:s.id,wave:s.wave,actualSourceDamage:s.actualSourceDamage,actualSourceCellDamage:s.actualSourceCellDamage,
  acceptedSourceHits:s.hits.length,acceptedPhysicalCellSourceHits:s.hits.filter(h=>h.physicalCellRoot).length,
  basicSourceDamage:sum(s.hits.filter(h=>h.data.cause==='basic').map(h=>h.actualHpLoss)),protocolSourceDamage:sum(s.hits.filter(h=>h.data.cause==='protocol').map(h=>h.actualHpLoss)),
  actualKill:s.actualKill,exhausted:s.naturalExhaustion,quotaBorn:s.quotaBorn,canceled:s.canceled,sourceBirthToFirstHit:s.timeBirthToFirstHit,sourceBirthToRemoval:s.timeBirthToRemoval,
  warningTravel:s.warningTravel,combatTravel:s.combatTravel}));
 cases.push({...task,actualCellHits:hits.length,actualCellDamage:damage,actualCellDamageToSource:sum(hits.filter(h=>h.id.startsWith('endless-source:')).map(h=>h.damage)),
  physicalSourceHitCount:hits.filter(h=>h.id.startsWith('endless-source:')).length,totalAcceptedSourceDamage:sum(sources.map(s=>s.actualSourceDamage)),
  sourceObserverCellDamage:sum(sources.map(s=>s.actualSourceCellDamage)),duplicateKeys:duplicates,sourceHits:sources,
  focusedCommands:obs.immune.focusedCommands,focusedCommandsWithPositiveBites:obs.immune.focusedCommandsWithPositiveBites,
  distantCommands:obs.immune.distantCommands,distantCommandsWithPositiveBites:obs.immune.distantCommandsWithPositiveBites,distantDamage:obs.immune.distantAcceptedDamage});
}
const groups=['near','rush'].map(route=>{const rs=cases.filter(c=>!c.replay&&c.route===route);return{route,independentCases:rs.length,actualCellHits:sum(rs.map(r=>r.actualCellHits)),
 actualCellDamage:sum(rs.map(r=>r.actualCellDamage)),actualCellDamageToSource:sum(rs.map(r=>r.actualCellDamageToSource)),physicalSourceHitCount:sum(rs.map(r=>r.physicalSourceHitCount)),
 totalAcceptedSourceDamage:sum(rs.map(r=>r.totalAcceptedSourceDamage)),focusedCommands:sum(rs.map(r=>r.focusedCommands)),focusedCommandsWithPositiveBites:sum(rs.map(r=>r.focusedCommandsWithPositiveBites)),
 distantCommands:sum(rs.map(r=>r.distantCommands)),distantCommandsWithPositiveBites:sum(rs.map(r=>r.distantCommandsWithPositiveBites)),distantDamage:sum(rs.map(r=>r.distantDamage))};});
const addendum={method:'Derivation only from unchanged fixed13 raw: positive actual TARGET_HIT protocol IMMUNE_BEACON, valid physical cell/:bite root and matching event tick; dedup tick/root/target and exact independent check against original cumulative positive-HP counter.',
 groups,cases,allActualCountersMatch:true,duplicates:sum(cases.map(c=>c.duplicateKeys.length)),newSimulationRuns:0,
 limits:['Q commands are denominators, not damage. Automatic cells and incidental near-route source hits remain in the live world; no withholding fire or injected hit.',
 'These v0810 cell amounts are new route outcomes; do not reuse the v089 contribution numbers or attribute every difference to a single direct buff.',
 'Free eight-second prepositioning remains: every rush source first hit is one fixed tick after birth. No human readability or strategy motivation is inferred.']};
const bytes=JSON.stringify(addendum,null,2)+'\n',file=resolve(output,'derived/actual-cell-contribution.json'),f=await open(file,'wx');try{await f.writeFile(bytes);}finally{await f.close();}
const brief=['# v0.8.10 真实细胞贡献补充','',...groups.map(g=>`${g.route}：${g.actualCellHits}次真实细胞正伤、${g.actualCellDamage.toFixed(3)}实际伤害；其中源受击${g.physicalSourceHitCount}次、${g.actualCellDamageToSource.toFixed(3)}伤害。源全部实际正伤${g.totalAcceptedSourceDamage.toFixed(3)}。`),'',
 '全部13局按实际HP损失与cell bite根身份去重后，均与旧驱动的真实伤害累计吻合；重复0，没有新增模拟。免费预警预定位和偶然清源仍保留，不能据贡献数字宣称多目标平衡或真人爽快通过。',''].join('\n');
const md=await open(resolve(output,'derived/actual-cell-contribution.md'),'wx');try{await md.writeFile(brief);}finally{await md.close();}
console.log(JSON.stringify({groups,duplicates:addendum.duplicates,file}));
