import pathlib,json,hashlib,stat,zipfile
from datetime import datetime,timezone
tool=pathlib.Path(__file__).resolve().parent;root=tool.parents[2]
output=root/'artifacts/source-v0810/measurement-attempt-1';old=root/'artifacts/source-v089/measurement-attempt-1'
archive=output/'measurement-records.complete.zip';manifest_path=output/'measurement-records.complete.manifest.json';index_path=output/'measurement-records.complete.index.json'
if any(p.exists() for p in [archive,manifest_path,index_path]):raise RuntimeError('Preserve prior complete archive')
sha=lambda data:hashlib.sha256(data).hexdigest()
origin_path=tool/'frozen-candidate/origin.json';origin=json.loads(origin_path.read_text(encoding='utf-8'));assert len(origin['files'])==50
paths={p.relative_to(output).as_posix():p for p in sorted(output.rglob('*')) if p.is_file()}
for name in ['plan.json','measure.mjs','source-observer.mjs','preparation.json','analyze.mjs','immune-addendum.mjs','archive-complete.py']:paths['tools/'+name]=tool/name
paths['frozen-candidate/origin.json']=origin_path
for rel,entry in origin['files'].items():
 p=tool/'frozen-candidate'/rel;assert not p.is_symlink() and sha(p.read_bytes())==entry['sha256'];paths['frozen-candidate/'+rel]=p
for name in ['report.json','strategy-compatibility.json','derived/comparison.json','measurement-records.complete.index.json']:
 paths['reference-v089/'+name]=old/name
entries=[]
for name,p in sorted(paths.items()):
 assert not p.is_symlink();data=p.read_bytes();entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
assert sum(e['path'].startswith('seed-') and e['path'].endswith('.json') for e in entries)==13
manifest={'schemaVersion':1,'createdAtUtc':datetime.now(timezone.utc).isoformat(),'newRawCases':13,'independentCases':12,'predeterminedReplayCases':1,'fullFrozenCandidateInputs':50,
 'scope':'v0.8.10 fixed13 source-route simulation, all50 source inputs, original unchanged public driver and source/cycle observers, runtime bundle, original v089 binding references and complete new derived comparisons/contribution.',
 'priorEvidence':'Original v089 fixed13 and late2 are retained unchanged, referenced only; no additional baseline or late long run is included.',
 'limits':['The old v089 source blocked fast-clear pursuit, so prior rush time advantage had a scheduling regression component. New comparison lists every paired old/new case and direct source-alive pursuit receipts.',
 '54.748 seconds of accepted simulated schedule reductions need not equal57.467 seconds of feedback-driven simulated elapsed change. Neither number is a wall-clock performance measurement.',
 'Score/bestCombo was posthoc for original v089 and prospectively listed for this v0810 matrix. The original time/player-loss/organ-loss objective set remains separate.',
 'SOURCE_EXHAUSTED unspent HP is neither damage nor clear/XP. Original per-step budget/population/geometry/duplicate checks are retained; old last-snapshot next-wave stamp limitation is disclosed.',
 'This is a1..16 fixed matrix with free warning prepositioning still possible. No new late26/all35/browser/GPU/human-fun qualification is inferred.'],
 'manifestRule':'All payload entries hashed; embedded archive-manifest.json is these exact bytes and is separately hashed in external index.','files':entries}
data=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
with manifest_path.open('xb') as f:f.write(data)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for entry in entries:z.write(paths[entry['path']],entry['path'])
 z.writestr('archive-manifest.json',data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None;names=z.namelist();assert len(names)==len(set(names))==len(entries)+1 and set(names)==set(paths)|{'archive-manifest.json'}
 assert all(not stat.S_ISLNK(i.external_attr>>16) for i in z.infolist());assert z.read('archive-manifest.json')==data
 for entry in entries:
  content=z.read(entry['path']);assert len(content)==entry['bytes'] and sha(content)==entry['sha256'];assert sha(paths[entry['path']].read_bytes())==entry['sha256']
 for rel,entry in origin['files'].items():assert sha(z.read('frozen-candidate/'+rel))==entry['sha256']
index={'archive':archive.relative_to(root).as_posix(),'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'manifest':manifest_path.relative_to(root).as_posix(),
 'manifestSha256':sha(data),'payloadFiles':len(entries),'zipEntries':len(entries)+1,'newRawCases':13,'frozenCandidateInputs':50,'crcPassed':True,'allPayloadHashesMatch':True,
 'all50FrozenInputsMatchOrigin':True,'originalEvidenceRetainedUnchanged':True,'scope':manifest['scope'],'limits':manifest['limits']}
with index_path.open('x',encoding='utf-8') as f:json.dump(index,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(index,ensure_ascii=False))
